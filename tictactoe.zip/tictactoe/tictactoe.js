const gameboard = document.querySelector('#main')
gameboard.classList.add('gameframe')

for(let i=0; i<6; i++) {
    const cell = document.createElement('div')
    cell.classList.add('cell')
    cell.id = i+1
    
    for(let j=0; j<6; j++) {
        const single = document.createElement('div')
        single.classList.add('single')
        single.id = `${j+1}-innerId`
        single.addEventListener('click', handleClick)

        cell.appendChild(single)
    }
    gameboard.appendChild(cell)
}

const button = document.createElement('button')
button.innerText = 'restart'
button.classList.add('button')
button.addEventListener('click', clickButton)
//appendChild means add button tag to gameboard div in html file//gamboard is parent div, button is one child div
gameboard.appendChild(button)

////////////////////////////////////////////////////////////
const x_div = gameboard.querySelectorAll('.single')

let itemsArr = Array(6)
for(let i=0; i<itemsArr.length; i++) {
    itemsArr[i] = Array(6)
}

function handleClick(e) {
    //insert X or O
    itemInsert(e)
    //create arr of items
    updateItemsArr(e)
    //horizontal checker
    horizontalChecker()
    //cats game checker
    catsGameChecker()
}

function itemInsert(e) {
    const el = e.target
    let countX = 0//why out of function, every 2 items changes
    let countO = 0
    for(let x of x_div) {
        if(x.innerText === 'X') {
            countX++
        } else if(x.innerText === 'O') {
            countO++
        }
    }

    if(el.nodeName === 'DIV') {
        if(countX - countO === 1) {
            if(el.innerText === 'X') {
                el.innerText = 'X'
                el.classList.add('red')    
            } else {
                el.innerText = 'O'
                el.classList.add('black')
            } 
        } else if(countX - countO === 0) {
            if(el.innerText === '') {
                el.innerText = 'X' 
                el.classList.add('red')   
            } else if(el.innerText === 'O') {
                el.innerText = 'O'
                el.classList.add('black')
            } else {
                el.innerText = 'X'
                el.classList.add('red')  
            }  
        }
    } 
}

function updateItemsArr(e) {
    const itemSign = e.target.innerText
    const firstIndex = parseInt(e.target.parentNode.id)   //need parseInt
    const secondIndex = parseInt(e.target.id[0])
    itemsArr[firstIndex-1][secondIndex-1] = itemSign//problem
    console.log(itemsArr)
}

function horizontalChecker() {
    for(let i=0; i<itemsArr.length; i++) {
        inner_loop1:
        for(let j=0; j<itemsArr.length; j++) {
            if(itemsArr[i][j] !== undefined && itemsArr[i][j] === itemsArr[i][j+1] && itemsArr[i][j+1] === itemsArr[i][j+2]) {
                //if innerText is non value, it is undefined! remember it!
                alert(`${itemsArr[i][j]} has won`)
                x_div.forEach(div => div.removeEventListener('click', handleClick))
                return
            }
            if(j+2 > itemsArr.length-1) {
                break inner_loop1
            }    
        }
    }    
}

function catsGameChecker() {
    //x_div is an object, not an array
    let hasUndefined
    for(let div of x_div) {
        if(div.innerText === '') {
            hasUndefined = true
            break
        } else {
            hasUndefined = false
        }
    }
    if(!hasUndefined) {
        alert('cats game')
        x_div.forEach(div => div.removeEventListener('click', handleClick))
        return
    }
}

function clickButton() {
    //clear itemsArr...
    itemsArr = itemsArr.map(item => item.map(one => undefined))
    x_div.forEach(div => div.classList.value = 'single')


    for(let el of x_div) {
        el.innerText = ''
        el.addEventListener('click', handleClick)    
    }  
    

}






